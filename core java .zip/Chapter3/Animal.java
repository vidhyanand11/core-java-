package Chapter3;

public class Animal {
	
	int legs;
	String color;
	
	Animal(int legs,String color)
	{
		System.out.println("In parent class");
		this.legs=legs;
		this.color=color;
		
	}
 

	
	public static void main(String args[])
	{
		Cat c=new Cat(4,"red","white");
		System.out.println(c.color);
		System.out.println(c.legs);
		
	}
}
class Cat extends Animal
{
	String color;
	Cat(int legs,String color ,String color1)
	{
		super( legs,color);//only we can use super or this at time and it must have first line.
		
		System.out.println("In child class");
		this.color=color1;
	}
}
	

