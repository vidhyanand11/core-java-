package Chapter3;

public class Static {
	
		int id;
		String name;
		static String Batchcode;
		public Static(int id, String name) {
			this.id = id;
			this.name = name;
		}
		static// Static block
		{
			System.out.println("Static Block");
		}
		{
			System.out.println("Annonymous Block");
		}

		
static void setRules()
{
	Batchcode="CT109";
	System.out.println(Batchcode);
}
	void displayData()
	{
		System.out.println(id);
		System.out.println(name);
		Static.setRules();// static method declared using class name;
	}
	public static void main(String args[]) {
		System.out.println("Start of main");
		Static d=new Static(101,"javed");
		d.displayData();
		//d.setRules();
		
	}
		
	

}
