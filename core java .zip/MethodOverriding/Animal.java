package MethodOverriding;

public class Animal {
	
	 public void eat(int Quntity)
	{
	System.out.println("Eat Grass");	
	}
	 public void jump1()
	 {
		 System.out.println("jumping");
	 }
	public static void main(String args[])
	{
		Cat c=new Cat();//down casting also called as static binding. 
		c.eat(5);
		c.jump();
	//	Cat c1=new Animal();// it shows runtime error.
		Animal b=new Cat();//up casting also called as dynamic binding.
		
		//b.jump;// it show an error it cannot access unique property of child class.
		b.eat(0);// down casting 
		Cat c1=(Cat) b;
		b.jump1();
		c1.jump();// now we can access unique property using down casting.
		
	}
}
	class Cat extends Animal
	{
	@Override
	public	void eat(int Quntity)//The parameter should be Same as Parent Method 
							// Method name should be same.
							// Data type Should be same of method.
							// covarient are allowed;						//Scope should not be restricted. scope means visibility. private is not for parent.

	{
		super.eat(5);
			System.out.println("Drink Milk");
		}
	
	void jump()
	{
		System.out.println("jump");
	}
	}
