package $chapter2$;

import java.util.Scanner;

public class Student {
	
	String Name;
	int  RollNo;
	String Location;
	public Student(String name, int rollNo, String location) {
		super();
		Name = name;
		RollNo = rollNo;
		Location = location;
	}
	void goSchool() {
		System.out.println("Going to School");
	}
	 void doHomework() {
		 System.out.println("Doing Homework");
	 }
	 void displayData()// display data using method
	 {
		 System.out.println(Name);
			System.out.println(RollNo);
			System.out.println(Location);
		
	 }
	public static void main(String args[])
	{
		System.out.println("Enter Your Roll no:");
		Scanner b=new Scanner(System.in);
		int RollNo=b.nextInt();
		System.out.println("Enter Your Name:");
		Scanner a=new Scanner(System.in);
		String Name=a.next();
		System.out.println("Enter your  location");
		String Location=a.next();
		
		Student s1=new Student("Atish Tupe",101,"karjat");
		Student s2=new Student("Pramod Patil",102,"sion");
		s1.goSchool();
		System.out.println("Name="+s1.Name);
		System.out.println("Roll No="+s1.RollNo);
		System.out.println("Location="+s1.Location);
		s2.goSchool();
		System.out.println("Name="+s2.Name);
		System.out.println("Roll No="+s2.RollNo);
		System.out.println("Location="+s2.Location);
		
		Student s3=new Student(Name,RollNo,Location);
		s3.displayData();
	
		
	}
	

}
