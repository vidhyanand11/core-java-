package $chapter2$;

public class Employee {
	String Name;
	int  Eid;
	String Location;
	public Employee(String name, int Eid, String location) {
		super();
		Name = name;
		this.Eid = Eid;
		Location = location;
	}
	void goforJob() {
		System.out.println("Going to company");
	}
	 void doHardwork() {
		 System.out.println("Doing work");
	 }
	 void displayData()// display data using method
	 {
		 System.out.println(Name);
			System.out.println(Eid);
			System.out.println(Location);
		
	 }
	public static void main(String args[])
	{
		Employee s1=new Employee("Atish Tupe",101,"karjat");
		Employee s2=new Employee("Pramod Patil",102,"sion");
		Employee s3=new Employee("Vidhyanand",103,"Dombivali");
		System.out.println("EName="+s1.Name);
		System.out.println(" Eid="+s1.Eid);
		System.out.println("Location="+s1.Location);
		System.out.println("Name="+s2.Name);
	
		System.out.println("Eid="+s2.Eid);
		System.out.println("Location"+s2.Location);
		s3.displayData();// dispalying Data using method 
	}
	

}
