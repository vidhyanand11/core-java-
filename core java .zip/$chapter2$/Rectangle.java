package $chapter2$;

import java.util.Scanner;

public class Rectangle {

	float length;
	float breadth;
	
	public Rectangle(float length, float breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
		void displayResult()
		{
			System.out.println("The Area is="+(length*breadth));
		}
		int area(int length, int breadth)
		{
			int result=length*breadth;
			return result;
					}
		
		public static void main(String args[])
		{
			System.out.println("Enter height:");
			Scanner b=new Scanner(System.in);
			float length=b.nextFloat();
			System.out.println("Enter breadth:");
			float breadth=b.nextFloat();
			Rectangle r=new Rectangle(length,breadth);
		r.displayResult();
					
		}

	
	
}
