package $chapter2$;

public class ThisDemo1 {
	int num1;
	int num2;
	{
		System.out.println("The Number is=");
	}
	public ThisDemo1(int num1, int num2) {

		this.num1 = num1;
		this.num2 = num2;
	}

	ThisDemo1()
	{
		this(15,10);// for zero costructor
	}   
public static void main(String args[])
{
	ThisDemo1 ab=new ThisDemo1();
	ThisDemo1 ac=new ThisDemo1(5,5);// instance variable hiding 
	System.out.println(ac.num1+ " "+ac.num2);
	System.out.println(ab.num1+ ""+ab.num2);
}

}
