package $chapter2$;

public class A {
	public static void main(String args[]) {
		
	}

}
 class B
{
	
}