package $chapter2$;

public class Anonymous {
	int num1;
	int num2;
	{
		System.out.println("The Number is=");
	}
	public Anonymous(int num1, int num2) {

		this.num1 = num1;
		this.num2 = num2;
	}

	Anonymous()
	{
		this(15,10);// for zero costructor
	}   
public static void main(String args[])
{
	Anonymous ab=new Anonymous();
	Anonymous ac=new Anonymous(5,5);// instance variable hiding 
	System.out.println(ac.num1+ " "+ac.num2);
	System.out.println(ab.num1+ ""+ab.num2);
}

}
