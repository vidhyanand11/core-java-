package $chapter2$;

import java.util.Scanner;

public class Circle {
	float r; 

	public Circle(float r) {
		super();
		this.r = r;
	}
	float area(float r){
		
	float	Result=(float) (3.14*r*r);
		return Result;
		
	}
	float circumfernce(float r)
	{
		float Result=(float) (2*3.14*r);
		return Result;
		
	}
	public static void main(String args[])
	{
		System.out.println("Enter the value of radius");
		Scanner b=new Scanner(System.in);
		float r=b.nextFloat();
		Circle a=new Circle(r);
		Circle c=new Circle(r);
		System.out.println("the area of circle is:"+a.area(r));
		System.out.println("the circumference is :"+c.circumfernce(r));
		
		
	}

}
