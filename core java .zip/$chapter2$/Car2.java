package $chapter2$;

public class Car2 {
	String color;
	String modelNo;
	String size;
	public Car2(String color, String modelNo, String size) {
		super();
		this.color = color;
		this.modelNo = modelNo;
		this.size = size;
	}
	public Car2() {
		
	}

	void startEngine() { 
		System.out.println("started");
	}

	void stopEngine() {
		System.out.println("stopped");
	}
	
		public static void main(String args[])
		{
			Car2 c3 = new Car2();// null values 

			System.out.println(c3.modelNo);
			System.out.println(c3.size);
			
			Car2 c = new Car2("red","5464ats", "medium");
		
			System.out.println(c.color);
			System.out.println(c.modelNo);
			System.out.println(c.size);
			Car2 c1 = new Car2("Black","5464promo", "small");
			System.out.println(c1.color);
			System.out.println(c1.modelNo);
			System.out.println(c1.size);
			
			
		}

		

	
}
