package $chapter2$;

public class Car {
	String color="Red";
	String modelNo="1XPROMOU44";
	String size="MEDIUM";
	
	void startEngine() { 
		System.out.println("started");
	}
	
	void stopEngine() {
		System.out.println("stopped");
	}
	public static void main(String args[])
	{ 
		// to initiallize variable constructor used
		Car c = new Car();
		c.startEngine();
		c.stopEngine();
		System.out.println(c.color);
		System.out.println(c.modelNo);
		System.out.println(c.size);
		// creating new instance
		Car c1 = new Car();
		c1.startEngine();
		c1.stopEngine();
		System.out.println(c1.color);
		System.out.println(c1.modelNo);
		System.out.println(c1.size);
		

		
		}

}
