package $chapter2$;

public class Doctor {
	String CardioSpecialist;
	String Speciallization;
	String orthopadic;

	public Doctor(String orthopadic, String cardioSpecialist, String speciallization) {
		
		this.orthopadic = orthopadic;
		CardioSpecialist = cardioSpecialist;
		Speciallization = speciallization;
	}
	
	
	void onDuty()
	{
		System.out.println(" Doctor is in Operation Theater");
	}
	public static void main(String args[]) {
	Doctor d= new Doctor("MuscularProblems", "HeartProblem", "Surgery");
	d.onDuty();
	System.out.println("Our Doctor are Specialist:"+""+d.orthopadic);
	System.out.println("Our Doctor are Specialist:"+d.CardioSpecialist);
	
	
	}

}
