package $chapter2$;

public class Addition {

	int  addition(int a, int b, int c)
	{
		int R=a+b+c;
		return R;
	}
	int addition(int a, int b)
	{
		int R=a+b;
		return R;
	}
	float addition(float a, float b)
	{
		float R=a+b;
		return R;
	}
	public static void main(String args[])
	{
		Addition a=new Addition();
		System.out.println(a.addition(12, 15));
		System.out.println(a.addition(12, 16,4));
		System.out.println(a.addition(12.5f, 12.1f));




	}

}
