package pattern;

public class pattern8 {
	public static void main(String args[])
	{
		int i,j;

		for(i=4;i>=1;i--)
		{
			for(j=5;j>=i;j--)
			{
				System.out.print(" "+j);
			}
			System.out.println();
		}
		for(i=1;i<=5;i++)
			{
				for(j=5;j>=i;j--)
				{
					System.out.print("");
				}
				System.out.println();

	}
		
}
	}

