package pattern;

public class pattern7_reverse {
	public static void main(String args[])
	{
		int row=5;
		for(int i=row;i>=1;i--)
		{
			for ( int j =1;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();


	    }
		for(int i=2;i<=5;i++)
		{
			for ( int j =1;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();


}
}
}

