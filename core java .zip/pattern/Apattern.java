package pattern;

public class Apattern {
	public static void main(String args[])
	{
		int i,j;
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5;j++)
			{
	if(j==1 || i==1 || i==3 || (i+j)==10)
	{

	System.out.print("*");
     }
else
{
	System.out.print(" ");
}
	}
System.out.println();


}
	}
}
