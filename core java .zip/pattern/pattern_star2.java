package pattern;

public class pattern_star2 {
	public static void main(String args[])
	{
		int i,j;
		for(i=5;i<=5;--i)
		{
			for(j=5;j<=5;j++)
			{
				System.out.print("*");
				
			}
			System.out.println();
		}
	}

}
