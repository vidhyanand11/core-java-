package pattern;

public class Armstrongno1_1000 
{
	public static void main(String args[])
	{
		int num,sum=0,rem;
	System.out.println("check no between 1 to 1000 armstrong or not");
 for(int i=1;i<=1000;i++)
	{
	 num=i;
	 while(num>0)
	 {
	 rem=num%10;
	 num=num/10;
	 sum=sum+(rem*rem*rem);
	}
	 if(sum==i)
	 {
		 System.out.println(i+" ");
	 }
	
	}
	}
}
	
	



