package pattern;

import java.util.Scanner;

public class Factorial_exmp {
	public static void main(String args[])
	{
		int  num,fact=1;
		Scanner Sc=new Scanner(System.in);
		System.out.println("enter a no:");
		num=Sc.nextInt();
		for(int i=1;i<=num ;i++)
		{
			fact=i*fact;
		}
		System.out.println("factorial of 5 is:"+fact);
	}
}
