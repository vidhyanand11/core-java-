package $Chapter1$;

public class Star {
	public static void main(String args[])
	{
		int i;
		for(int j=0;j<=5;j++)
		{
		for(i=0;i<=5;i++)
		{
			System.out.print(i++);
			
		}
		System.out.println();
		}
		}
	}


