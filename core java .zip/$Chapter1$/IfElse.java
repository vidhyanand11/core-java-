package $Chapter1$;

public class IfElse {
	public static void main(String args[])
	{
		int A=10;
		if(A>0)
		{
		System.out.println("it is Positive Number");
		}
		else
		{
		System.out.println(" It is Negative Nummber");
		}
	}

}
