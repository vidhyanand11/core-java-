package $Chapter1$;

import java.util.Scanner;

public class AtmImlementation {
	public static void main(String args[])
	{
		int pin=1998; int Amount = 0; int choice;  int Balance=100000; int newPin; int depositAmount;
	do
	{
		
		System.out.println("1-> Balance Enquiry");
		System.out.println("2-> Cash Withdrawal ");
		System.out.println("3-> Change Pin");
		System.out.println("4-> Deposit ");
		System.out.println("5-> Exit");
		System.out.println("Enter Your choice");
		
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	choice=sc.nextInt();
	switch(choice)
	{
	case 1:{
		System.out.println("Please Enter Your Pin");
		@SuppressWarnings("resource")
		Scanner nc=new Scanner(System.in);
		newPin=nc.nextInt();
		if(pin==newPin)
		{
		System.out.println("Your Balance Amount"+Balance);
		}
		else
		{
			System.out.println("Invalid Pin");
		}
	}
	break;
	case 2:{
		System.out.println("Please Enter Your Pin");
		@SuppressWarnings("resource")
		Scanner nc=new Scanner(System.in);
		newPin=nc.nextInt();
		if(Amount<Balance)
		{
		System.out.println("Enter Amount");
		@SuppressWarnings("resource")
		Scanner ac=new Scanner(System.in);
		Amount=ac.nextInt();
		if(Amount>Balance)
		{
			System.out.println("Insufficient Balance Withdraw Request Cancelled");
		
		}
		else 
		{
			System.out.println("Transaction Successfull Please Collect Your Amount"+Amount);
			Balance=Balance-Amount;
		}}
		else
		{
		System.out.println("Invalid Pin");
		}
	
	}break;
		case 3:
		{
			System.out.println("Please Enter Your Current Pin");
			@SuppressWarnings("resource")
			Scanner nc=new Scanner(System.in);
			newPin=nc.nextInt();
			if(pin==newPin)
			{
			System.out.println("Enter Your New Pin");
			@SuppressWarnings("resource")
			Scanner ac=new Scanner(System.in);
			newPin=ac.nextInt();
			pin=newPin;
			System.out.println("Your Pin Changed");}
			else
			{
				System.out.println("Invalid Pin");
			}
	
		
		} break;
		case 4:
		{
			System.out.println("Enter amount for deposit");
			@SuppressWarnings("resource")
			Scanner tp=new Scanner(System.in);
			depositAmount=tp.nextInt();
		Balance=Balance+depositAmount;
		System.out.println("Amount Deposited Successfully");

		}break;
		case 5:
		{
			System.exit(0); 
		}
	default : {
		System.out.println("Invalid Input");
	}
	}
	}while(choice>0);
	
	}
}
	