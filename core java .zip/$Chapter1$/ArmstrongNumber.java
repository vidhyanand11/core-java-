package $Chapter1$;

import java.util.Scanner;

public class ArmstrongNumber {
	public static void main(String args[])
	{
		int num; int pal=0; int rem; int temp;
		System.out.println("Enter The Number");
		@SuppressWarnings("resource")
		Scanner at=new Scanner(System.in);
		num=at.nextInt();
		temp=num;
		while(num>0)
		{
			rem=num%10;
			num=num/10;
			pal =pal+(rem*rem*rem);		
		}
          if (pal==temp)
          {
        	  System.out.println("This Is Armstrong Number");
        	  
          }
          else
          {
         	  System.out.println("This Is  Not An Armstrongg  Number "); 	  
          }
}}
