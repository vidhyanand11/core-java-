package $Chapter1$;

import java.util.Scanner;

public class Multiplication {

	public static void main(String args[])
	{
			int m; int n; int mul=1;
			System.out.println("Enter The Number");
			Scanner at=new Scanner(System.in);
			m=at.nextInt();
			
			while(m>0)
			{
				n=m%10;
				mul=mul*n;
				m=m/10;
						
			}
	         System.out.println("Multiplication Of Digit is "+mul);	  
	          }
		}
	

