package $Chapter1$;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String args[])
	{
		int choice;
		int num1=10; int num2=20;
		
		System.out.println("1. ADDITION");
		System.out.println("2. SUBSTRACTION");
		System.out.println("3. MULTIPLICATION");
		System.out.println("4. DIVISION");
		System.out.println("Enter Your Choice");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:{
			System.out.println("Addition="+(num1+num2));
		}
		break;
		case 2:{
			System.out.println("Subtraction="+(num1-num2));
		}
		break;
		case 3:{
			System.out.println("Multiplication="+(num1*num2));
		}
		break;
		case 4:{
			System.out.println("Division="+(num1/num2));
		}
		break;
	default :{
		System.out.println("Invalid Choice");
	} 

		}
	}
}
