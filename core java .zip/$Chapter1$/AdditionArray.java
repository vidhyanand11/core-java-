package $Chapter1$;

import java.util.Scanner;

public class AdditionArray {
	public static void main(String args[])
	{
		int i; int j; int k;
		int[] arr1= new int [2];
		int[] arr2= new int [2];
		int[] arr3= new int [2];
		 System.out.println("Enter Number num 1");
			Scanner at=new Scanner(System.in);
			 arr1[1]=at.nextInt();
			 System.out.println("Enter Number num 1");
				Scanner ap=new Scanner(System.in);
				 arr2[1]=at.nextInt();
				
				 arr3[1]=arr1[1]+arr2[1];
				 System.out.println("The sum  is "+arr3[1]);
	}

}
