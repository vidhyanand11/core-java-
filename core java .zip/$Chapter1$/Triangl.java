package $Chapter1$;

public class Triangl {
	public static void main(String args[])
	{
	int i; int j; 
	for(i=1; i<=5; i++)
	{
		
	}
	}
}
