package $Chapter1$;

import java.util.Scanner;

public class WithdrawValidation {
	
	public static void main(String args[])
	{
		int Amount; int BalanceAmount=10000;
		System.out.println("Enter Withdraw Amount");
		Scanner Am=new Scanner(System.in);
		Amount=Am.nextInt();
		if(Amount<=10000)
		{
			System.out.println("Money Withdrawing........");
		}
		else
		{
			System.out.println("Not Allowed to withdraw");
		}
	}

}
