		package $Chapter1$;
		
		import java.util.Scanner;
		
		public class TwoDArray {
			public static void main(String args[])
			{
			int a[][]=new int[5][5];  int i; int j;
			System.out.println("Enter Element for Array");
			Scanner at=new Scanner(System.in);
			for( i=0; i<5; i++ )
			{
				for( j=0; j<5; j++)
				{
					a[i][j]=at.nextInt();
				}
				}
				
				for( i=0; i<5; i++ )
				{
					for( j=0; j<5; j++)
					{
				System.out.print("The Array is "+a[i][j]);
			
			}
		}
		
			}
		}
			
