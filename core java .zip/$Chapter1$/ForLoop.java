package $Chapter1$;

public class ForLoop {
	public static void main(String args[])
	
	{
		char alpha;
		for(int j=1;j<10;j++)
		{
			alpha='a';
		for(int i=1;i<=j;i++)
		{
		
			if(j%2==0)
			{
				System.out.print(alpha);
				alpha++;
			}
			else
			{
				System.out.print(+i);
			}
		
		}
	
		System.out.println();
		}
		}
	}




