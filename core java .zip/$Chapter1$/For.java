package $Chapter1$;

public class For 
{
public static void main(String args[])
{
	for(char j='A'; j<='E'; j++)
	{
		for(char i='A'; i<='E'; i++)
		{
	System.out.print(i);
	
		}
		System.out.println();
	}
		
	}

}
