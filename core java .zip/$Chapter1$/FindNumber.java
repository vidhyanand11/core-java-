package $Chapter1$;

import java.util.Scanner;

public class FindNumber {
	public static void main(String args[])
	{
	 int i; int size; int SearchNum = 0;  int flag = 0;
	System.out.println("Enter the value for array");
	Scanner kt=new Scanner(System.in);
	size= kt.nextInt();
	int[] arr= new int [size];
	 System.out.println("Enter Element");
	Scanner at=new Scanner(System.in);
	   for(i=0; i<arr.length; i++)
	   {	   
		   arr[i]=at.nextInt();
	   }
		System.out.println("Enter the Number that you search for");
		Scanner ap=new Scanner(System.in);
		SearchNum=ap.nextInt();
		for(i=0; i<arr.length; i++)
		{
	   if(SearchNum==arr[i])
	   {
		 flag=1;
		 break;
		 }
	   else
	   {
		   flag=0;
	   }}
		if(flag==1)
		{
			System.out.println("The Number"+SearchNum+" " +"is present");
		}
		else
		{
			System.out.println("Number not Found");
		}
	   }
	   }
	
	
