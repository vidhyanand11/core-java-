package $Chapter1$;

import java.util.Scanner;

public class Factorial {

	public static void main(String args[])
	{
		int i; int facto=1; int number;
		System.out.println("Enter The Number:");
		Scanner at=new Scanner(System.in);
		number=at.nextInt();
		for(i=1;i<=number;i++)
		{
			facto=facto*i;
		}
		System.out.println("The Factorial Of Number" +number+ "is"   +facto);
	}

}

