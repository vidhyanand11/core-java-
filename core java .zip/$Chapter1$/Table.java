package $Chapter1$;

import java.util.Scanner;

public class Table {
	public static void main(String args[])
	{
		int c; int i=1;
		System.out.println("Enter the Number");
		Scanner sc=new Scanner(System.in);
		c=sc.nextInt();
		while(i<=10)
		 {
			 System.out.println(i+"*"+c+"="+i*c);
			 i++;
		 }	
	
	}

}
