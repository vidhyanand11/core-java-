package $Chapter1$;

import java.util.Scanner;

public class Sorting {

	public static void main(String args[])
	{
	 int i; int size; int j; int temp=0;
	System.out.println("Enter the value for array");
	Scanner kt=new Scanner(System.in);
	size= kt.nextInt();
	int[] arr= new int [size];
	 System.out.println("Enter Element");
	Scanner at=new Scanner(System.in);
	   for(i=0; i<arr.length; i++)
	   {	   
		   arr[i]=at.nextInt();
	   }
	   for(i=0; i<arr.length; i++)
	   {
		   for(j=i+1; j<arr.length; j++)
		   {
			   if(arr[i]>arr[j])
			   {

				   temp=arr[i];
			   arr[i]=arr[j];
			   arr[j]=temp;
		   }
			   }}
		   for(int k=0; k<arr.length; k++)
		   {
			   System.out.println("Sorting List is "+arr[k]);
		   }
		   for(int x:arr)
		   {
			   System.out.println("Sorting list is"+x);
		   }
	   }
	}
	
