package $Chapter1$;

import java.util.Scanner;

public class BloodDonation {

	public static void main(String args[])
	{
		int age; int weight;
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter Your Age for Blood Donation");
		age=sc.nextInt();
		System.out.println("Enter Your Weight for Blood Donation");
		weight=sc.nextInt();


		if(age>=18 && age<=50)
		{

			System.out.println("Your Eligible For Blood Donation");
		}
		else
		{
			System.out.println("Your not Eligible for Blood Donation");
		}

	}	
}

