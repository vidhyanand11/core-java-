package $Chapter1$;

import java.util.Scanner;

public class Array {
	public static void main(String args[])
	{
	 int i; int size;
	System.out.println("Enter the value for array");
	Scanner kt=new Scanner(System.in);
	size= kt.nextInt();
	int[] arr= new int [size];
	 System.out.println("Enter Element");
	Scanner at=new Scanner(System.in);
	   for(i=0; i<arr.length; i++)
	   {	   
		   arr[i]=at.nextInt();
	   }
	   System.out.println("The Array Elements Are:");
		for( i=0; i<arr.length;i++)
		{
			System.out.print("\t"+arr[arr.length-1-i]);
		}
		for(i=arr.length-1; i<=0; i--)
		{
			System.out.print("\t"+arr[i]);
		}
		kt.close();
		at.close();
	}

}
