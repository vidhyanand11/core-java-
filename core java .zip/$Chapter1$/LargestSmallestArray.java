package $Chapter1$;

import java.util.Scanner;

public class LargestSmallestArray {

	public static void main(String args[])
	{
	 int i; int size;   int flag = 0;  int j; int largest=0;
	System.out.println("Enter the value for array");
	Scanner kt=new Scanner(System.in);
	size= kt.nextInt();
	int[] arr= new int [size];
	int[] num= new int [size];
	 System.out.println("Enter Element");
	Scanner at=new Scanner(System.in);
	   for(i=0; i<arr.length; i++)
	   {	   
		   arr[i]=at.nextInt();
		
	   
		
		for(j=0; j<arr.length; j++)
		{
			           ;
	   if(arr[j]>arr[i])
	   {
		arr[j]=largest;
		 }
	  System.out.println("The largest number is"+largest);
		}
	   }
	   }
	   }
	
	
