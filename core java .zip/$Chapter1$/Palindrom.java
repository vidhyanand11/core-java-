package $Chapter1$;

import java.util.Scanner;

public class Palindrom {
	public static void main(String args[])
	{
		int num; int pal=0; int rem; int temp;
		System.out.println("Enter The Number");
		Scanner at=new Scanner(System.in);
		num=at.nextInt();
		temp=num;
		while(num>0)
		{
			rem=num%10;
			num=num/10;
			pal =pal*10+rem;		
		}
          if (pal==temp)
          {
        	  System.out.println("This Is palindrome Number");
        	  
          }
          else
          {
         	  System.out.println("This Is  Not An palindrome Number "); 	  
          }
	}
}
