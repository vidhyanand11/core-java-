package $Chapter1$;

import java.util.Scanner;

public class NestedIfElse {
	
	public static void main(String args[])
	{
		int Marks;
		
		System.out.println("Enter the Number");
		Scanner sc=new Scanner(System.in);
		Marks=sc.nextInt();
		
		if(Marks<=100 && Marks>0) // Nested If
		{
		if(Marks>=75 && Marks<=100)
		{
			System.out.println("A Grade");
		}
		else if(Marks>=61 && Marks<=75)
		{
			System.out.println("B Grade");
			
		}
		else if(Marks>=46 && Marks<=60)
		{
			System.out.println("C Grade");
		}
		else if(Marks<35)
		{
			System.out.println(" You Are Failed");
		}
		} 
	//Nested Loop Else	
		else
		{
			System.out.println("No Such Value Exist");
		}

	}
}
