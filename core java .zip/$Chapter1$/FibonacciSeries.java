package $Chapter1$;

import java.util.Scanner;

public class FibonacciSeries {
	public static void main(String args[])
	{
		int num1; int num2; int sum=0 ;int i=1; int n;
		System.out.println("Enter first number");
		@SuppressWarnings("resource")
		Scanner oc= new Scanner(System.in);
		 num1=oc.nextInt();
		 System.out.println("Enter Second Number");
		 @SuppressWarnings("resource")
			Scanner bc= new Scanner(System.in);
			 num2=bc.nextInt();
		System.out.println("Enter range  for series ");
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		 n=sc.nextInt();
		while(i<=n)
		{
			System.out.println(+num1);
			sum=num1+num2;
			num1=num2;
			num2=sum;
			i++
			;
	}
		
	}

}
