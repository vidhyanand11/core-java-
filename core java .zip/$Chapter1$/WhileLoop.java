package $Chapter1$;

public class WhileLoop {
 public static void main(String args[])
 {
	 int a=0; int b=5; int c=2;
	 while(a<=5)
	 {
		 System.out.println(a);
		 a++;
	 }
	 while(b>=1)
	 {
		 System.out.println("\t"+b);
		 b--;
	 }	
	 
 }
}
