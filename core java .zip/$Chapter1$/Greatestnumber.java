package $Chapter1$;

import java.util.Scanner;

public class Greatestnumber {

	public static void main(String args[])
	{
		int num1; int num2; int num3;
		System.out.println("Enter The Num1");
		@SuppressWarnings("resource")
		Scanner at=new Scanner(System.in);
		num1=at.nextInt();
		System.out.println("Enter The Num2");
		@SuppressWarnings("resource")
		Scanner ab=new Scanner(System.in);
		num2=ab.nextInt();
		System.out.println("Enter The Num3");
		@SuppressWarnings("resource")
		Scanner ac=new Scanner(System.in);
		num3=ac.nextInt();
		if(num1>num2 && num1>num3)
		{
			System.out.println("Greatest Number is"+num1);
		}
		else if(num2>num1 && num2>num3)
		{
			System.out.println("Greatest Number is"+num2);	
		}
		else
		{
			System.out.println("Greatest Number is"+num3);
		}
	}
}
