package $Chapter1$;

import java.util.Scanner;

public class ElseIfLadder2 {
	public static void main(String args[])
	{
		int Marks;
		System.out.println("Enter the Number");
		Scanner ch=new Scanner(System.in);
		Marks=ch.nextInt();
		if(Marks>=75 && Marks<=100)
		{
			System.out.println("A Grade");
		}
		else if(Marks>=61 && Marks<=75)
		{
			System.out.println("B Grade");
			
		}
		else if(Marks>=46 && Marks<=60)
		{
			System.out.println("C Grade");
		}
		else if(Marks<35)
		{
			System.out.println(" You Are Failed");
		}
		else
		{
			System.out.println("Please contact Your Admin");
		}
	}

}
