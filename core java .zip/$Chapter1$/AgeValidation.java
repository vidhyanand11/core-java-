package $Chapter1$;

import java.util.Scanner;

public class AgeValidation {
	public static void main(String args[])
	{
		int age;
		System.out.println("Enter Your Age");
		Scanner ag=new Scanner(System.in);
		age=ag.nextInt();
		if(age>=18)
		{
			System.out.println("Your are Eligible For Voting");
		}
		else
		{
			System.out.println("Your not Eligible for Voting");
		}
	}

}
