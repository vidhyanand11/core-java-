package $Chapter1$;

public class ElseIfLadder {

	public static void main(String args[])
	{
		int A=0;
		if(A>0)
		{
		System.out.println("it is Positive Number");
		}
		else if(A<0)
		{
		System.out.println(" It is Negative Nummber");
		}
		else
		{
			System.out.println("A=0");
		}
	}

}
