package Inheritance;
import java.util.Scanner;
public class Organization {
int id;
String name;

	public Organization(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}
	void displayData()
	{
		System.out.println(id);
		System.out.println(name );	
	}
	public static void main(String args[])
	{		Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the Name:");
	String name =sc.next();
	System.out.println("Enter the id");
	int id=sc.nextInt();
	System.out.println("Enter the speciallization:");
	String Speciallization=sc.next();
	TOrg t= new TOrg( id, name, Speciallization);
	t.displayData();
	System.out.println(t.Speciallization);
	}
	}
	class TOrg extends  Organization
	{
		String Speciallization;

		public TOrg(int id, String name, String Speciallization) {
			super(id, name);
			this.Speciallization = Speciallization;
		}
	}
	

