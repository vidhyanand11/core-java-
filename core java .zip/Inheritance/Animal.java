package Inheritance;

public class Animal {
	String size="average";
	String food ="milk";
	public static void main(String args[])
	{
		dog d=new dog();
		cat c=new cat();
		tiger t=new tiger();
		System.out.println(d.color);
		System.out.println(d.food);
		System.out.println(c.run);
		System.out.println(c.food);
		System.out.println(t.film);
		
	}}
	class dog extends Animal
	{
		String color="white";
	}
	class cat extends Animal
	{
		String run="faster";
	}
	class tiger extends Animal
	{
		String film="Tiger Zinda hai";
	}


