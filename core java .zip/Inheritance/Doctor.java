package Inheritance;

import java.util.Scanner;

public class Doctor {
	private static int id;
	private static String name;
	private static String Speciallization;
	
 public Doctor(int id, String name, String speciallization) {
		super();
		this.id = id;
		this.name = name;
		Speciallization = speciallization;
	}

 public int getId()
{
	return id;
}
 public String getName()
 {
	 return name;
 }
 public String getSpeci()
 {
	 return Speciallization;
 }
 public void setId(int id)
 {
	 this.id=id;
	 
 }
 public void setName(String Name)
 {
	 this.name=name;
 }
 public void setSpeci(String speciallization)
 {
	 this.Speciallization=speciallization;
 }
public static void main(String args[])
{
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Id");
	id=sc.nextInt();
	System.out.println("Enter the name");
	name=sc.next();
	Doctor d=new Doctor(id,"name","Speciallization");
	System.out.println("Enter the speciallization");
	Speciallization=sc.next();
	System.out.println();
	Doctor d1=new Doctor(id, name, Speciallization);
	d.setId(id);
	d.setName(name);
	d.setSpeci(Speciallization);
	int id=d.getId();
	System.out.println(id);
	String name=d.getName();
	System.out.println(name);
	String speciallization=d.getSpeci();
	System.out.println();
}
}
