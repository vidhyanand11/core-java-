package Inheritance;

public class Vehicle {
	
 String modelno="maruti444";
 int averageSpeed=65;
 String color="Red";	
public static void main(String args[])
{
	maruti m=new maruti();
	car c= new car();
	System.out.println("model no is:"+c.modelno);
	System.out.println("model no is:"+m.modelno);
	System.out.println("color no is:"+m.color);
	
}}
 class car extends Vehicle
 {
	String modelno="lamborgini456"; 
 }
class maruti extends car
{
	String color="Red";
}
 

