package Inheritance;

public class Person {
	int id =101;
    String name="Atish";
    
	public static void main(String args[])
    {
    Student s=new Student();
    System.out.println(s.id);
    System.out.println(s.name);
    System.out.println(s.marks);
    }
}
class Student extends Person{
	
	float marks=60.00f;
    
	
}
class Employee extends Student
{
	
}
