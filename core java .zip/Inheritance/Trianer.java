package Inheritance;

public class Trianer {
	int id;
	String name;
	Address add;
	public Trianer(int id, String name, Address add) {
		super();
		this.id = id;
		this.name = name;
		this.add=add;
		
		
	}
	@Override
	public String toString() {
		return "Trianer [id=" + id + ", name=" + name + ", add=" + add + "]";
	}
	public static void main(String args[])
	{
	Address a=new Address("410101","karjat","maharashtra");
	Trianer t=new Trianer(101,"Atish",a);

	System.out.println(t);
	}
}
	class Address
	{
		String pincode;
		String city;
		String State;
		public Address(String pincode, String city, String state) {
			super();
			this.pincode = pincode;
			this.city = city;
			State = state;
		}
		@Override
		public String toString() {
			return "Address [pincode=" + pincode + ", city" + city + ", State=" + State + "]";
		}
	}
